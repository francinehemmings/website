---
layout: post
title: "Why you should consult?"
featured-img: osteopathy_symptomsToConsult
permalink: en-US/osteopathy_symptomsToConsult
language: en-US
---
- **Joint pain and inflammation**: neck, back, hips, knees, etc.

- **Visceral issues**:  Respiratory, digestive, circulatory, urinary, gynecological 
and sexual

- **Nerve issues**: Fatigue, insomnia, vertigo, depression, migraines, focus, etc.

- **Newborn troubles**: otitis, gastric reflux, colics, plagiocephaly, torticollis, breastfeeding
