---
layout: post
title: "Who can benefit from osteopathy?"
featured-img: osteopathy_whoCanBenefit
permalink: en-US/osteopathy_whoCanBenefit
language: en-US
---
Osteopathy is for everyone:
- pregnant women
- babies
- children
- teenagers 
- adults
- elderly