---
layout: post
title: "À qui s'adresse l'ostéopathie?"
featured-img: osteopathy_whoCanBenefit
permalink: fr-CA/osteopathy_whoCanBenefit
language: fr-CA
---
L’ostéopathie s’adresse à tous: 
- femmes enceintes
- bébés
- enfants
- adolescents
- adultes
- ainés