---
layout: post
title: "Quels signes incitent à consulter?"
featured-img: osteopathy_symptomsToConsult
permalink: fr-CA/osteopathy_symptomsToConsult
language: fr-CA
---
- **Douleurs et inflammation articulaires** : cou, dos et  membres

- **Affections organiques** : respiratoire, digestive, circulatoire, urinaire, sexuelle et gynécologique.

- **Affections nerveuses** : fatigue, insomnie, vertiges, dépression, migraines, concentration, etc.

- **Troubles nouveau-né** : otite, régurgitation, colique, plagiocéphalie, torticolis, sommeil, allaitement