---
layout: page
title: "Contact"
permalink: fr-CA/contact/
language: fr-CA
---
{% include_relative contactInfo.html %}
Cliquez ici pour m'envoyer un [courriel](mailto:{{site.email}}) ou un message
{% include form.html %}
{% include modal.html %}
