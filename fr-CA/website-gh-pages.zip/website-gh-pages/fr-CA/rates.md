---
layout: page
title: "Tarifs"
permalink: fr-CA/rates/
language: fr-CA
---
<h1>Tarifs et politique d'annulation</h1>
<table>
    <tr>
        <th>Consultation</th>
        <th>Durée</th>
        <th>Prix</th>
    </tr>
    <tr>
        <td>Adulte (plus de 12 ans)</td>
        <td>60 à 75 minutes</td>
        <td>100$ (taxes incluses)</td>
    </tr>
    <tr>
        <td>Enfant (12 ans et moins)</td>
        <td>45 à 60 minutes</td>
        <td>90$ (taxes incluses)</td>
    </tr>
</table>
Un rendez-vous peut être annulé sans frais 48 heures ou plus avant l'heure prévu.
Sinon, il y a un frais de 50$ si le rendez-vous est annulé à 48 heures ou moins 
de l'heure prévu.
